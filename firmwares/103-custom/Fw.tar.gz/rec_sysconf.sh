#!/bin/sh

# Replace <upload_directory> with the directory where you want to save the uploaded files
upload_directory="/tmp"

# Start listening on port 8001
while true; do
    echo "Waiting for file upload..."
    {
        echo -e "HTTP/1.1 200 OK\r"
        echo -e "Content-Type: text/plain\r"
        echo -e "\r"
        echo "File uploaded successfully!"
    } | nc -l -p 8001 > "$upload_directory/uploaded_file"
    
    if grep -q -x "\[System\]" $upload_directory/uploaded_file; then 
        echo "Found valid System config file"
        cp "$upload_directory/uploaded_file" /mnt/conf/SystemConfig.ini
        reboot
    fi 
    echo "Received invalid file!"
done

